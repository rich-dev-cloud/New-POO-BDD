package com.restaurante.services;

import com.restaurante.models.Address;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class CepService {
    private static String URL = "https://viacep.com.br/ws";

    public Address fetchAddressByCep(int cep) {
        Address address = null;

        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            HttpGet request = new HttpGet(String.format("%s/%d/json", this.URL, cep));
            CloseableHttpResponse response = httpClient.execute(request);
            String jsonResponse = EntityUtils.toString(response.getEntity());
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, String> jsonMap = objectMapper.readValue(jsonResponse, Map.class);

            String publicPlace = jsonMap.get("logradouro");
            String complement = jsonMap.get("complemento");
            String neighborhood = jsonMap.get("bairro");
            String city = jsonMap.get("localidade");
            String state = jsonMap.get("estado");

            address = new Address(0, publicPlace, complement, neighborhood, city, state, 0, cep);

            String addressMessage = String.format("Endereço:\n");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return address;
    }
}
