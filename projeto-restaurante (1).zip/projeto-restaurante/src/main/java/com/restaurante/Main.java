package com.restaurante;

import com.restaurante.models.*;
import com.restaurante.repository.*;
import com.restaurante.services.CepService;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DatabaseConnection connection = new DatabaseConnection();
        connection.connection();

        RestaurantRepository restaurantRepository = new RestaurantRepository(connection.getConnection());
        ProductRepository productRepository = new ProductRepository(connection.getConnection());
        AddressRepository addressRepository = new AddressRepository(connection.getConnection());
        OrderRepository orderRepository = new OrderRepository(connection.getConnection());
        ProductCartRepository productCartRepository = new ProductCartRepository(connection.getConnection());

        ArrayList<Product> productsSelected = new ArrayList<>();

        Restaurant selectedRestaurant = null;

        CepService cepService = new CepService();

        while (true) {
            String menuOption = JOptionPane.showInputDialog(
                    "Escolha uma opção abaixo\n1. Fazer novo pedido\n2. Listar pedidos"
            );

            if (menuOption.equals("1")) {
                ArrayList<Restaurant> restaurants = restaurantRepository.listAllRestaurants();

                String restaurantMessage = "Escolha um dos restaurantes abaixo:\n";

                for (int i = 0; i < restaurants.size(); i++) {
                    restaurantMessage += (i + 1) + ". " + restaurants.get(i).getNome() + "\n";
                }

                int restaurantOption = -1;
                while (restaurantOption < 1 || restaurantOption > restaurants.size()) {
                    restaurantOption = Integer.parseInt(JOptionPane.showInputDialog(restaurantMessage));

                    if (restaurantOption < 1 || restaurantOption > restaurants.size()) {
                        JOptionPane.showMessageDialog(
                                null,
                                "Digite uma opção correta!",
                                "Valor inválido!",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }

                selectedRestaurant = restaurants.get(restaurantOption - 1);

                int productContinues = 0;
                ArrayList<Product> products = productRepository.getOrdersByRestauranteId(restaurantOption);

                while (productContinues == 0) {
                    String productMessage = "Escolha um dos produtos abaixo:\n";

                    for (int i = 0; i < products.size(); i++) {
                        productMessage += (i + 1) + ". " + products.get(i).getNome() + "\n";
                        productMessage += String.format("R$%.2f\n", products.get(i).getPreco());
                    }

                    int productOption = -1;
                    while (productOption < 1 || productOption > products.size()) {
                        productOption = Integer.parseInt(JOptionPane.showInputDialog(productMessage));

                        if (productOption < 1 || productOption > products.size()) {
                            JOptionPane.showMessageDialog(
                                    null,
                                    "Digite uma opção correta!",
                                    "Valor inválido!",
                                    JOptionPane.ERROR_MESSAGE
                            );
                        }
                    }

                    productsSelected.add(products.get(productOption - 1));

                    productContinues = JOptionPane.showConfirmDialog(
                            null,
                            "Deseja adicionar mais produtos?",
                            "Adicionar mais produtos?",
                            JOptionPane.YES_NO_OPTION
                    );
                }

                String cepInput = "";

                while (cepInput.length() != 8) {
                    cepInput = JOptionPane.showInputDialog("Informe o seu CEP:");

                    if (cepInput.length() != 8) {
                        JOptionPane.showMessageDialog(
                                null,
                                "CEP Inválido!",
                                "CEP Inválido!",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }

                System.out.println("cepInput: " + cepInput);
                Address address = cepService.fetchAddressByCep(Integer.parseInt(cepInput));

                String addressMessage = String.format(
                        "Informe o número da casa:\nEndereço: %s\nBairro: %s\nCidade: %s\nEstado: %s\n",
                        address.getPublicPlace(),
                        address.getNeighborhood(),
                        address.getCity(),
                        address.getState()
                );

                String numberAddressInput = "teste";

                while (!Helpers.isNumeric(numberAddressInput)) {
                    numberAddressInput = JOptionPane.showInputDialog(addressMessage);

                    if (!Helpers.isNumeric(numberAddressInput)) {
                        JOptionPane.showMessageDialog(
                                null,
                                "Número de endereço inválido!",
                                "Número de endereço inválido!",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }

                System.out.println("Cheguei aqui!");
                address.setAddressNumber(Integer.parseInt(numberAddressInput));

                String formaPagamentoMessage = "Escolha um método de pagamento:\n";
                ArrayList<FormaPagamento> formaPagamentos = selectedRestaurant.getFormaPagamentos();

                for (int i = 0; i < formaPagamentos.size(); i++) {
                    formaPagamentoMessage += (i + 1) + ". " + formaPagamentos.get(i).getNome() + "\n";
                }

                int formaPagamentoOption = -1;
                while (formaPagamentoOption < 1 || formaPagamentoOption > products.size()) {
                    formaPagamentoOption = Integer.parseInt(JOptionPane.showInputDialog(formaPagamentoMessage));

                    if (formaPagamentoOption < 1 || formaPagamentoOption > products.size()) {
                        JOptionPane.showMessageDialog(
                                null,
                                "Digite uma opção correta!",
                                "Valor inválido!",
                                JOptionPane.ERROR_MESSAGE
                        );
                    }
                }

                FormaPagamento selectedFormaPagamento = formaPagamentos.get(formaPagamentoOption - 1);

                String itensMessage = "";

                for (int i = 0; i < productsSelected.size(); i++) {
                    itensMessage += String.format("- %s\n", productsSelected.get(i).getNome());
                }

                String completeOrderMessage = String.format(
                        "Detalhes do pedido:\n" +
                                "Restaurante: %s\n" +
                                "Itens: \n" +
                                itensMessage +
                                "Total: %.2f\n" +
                                "Forma pagamento: %s\n" +
                                "Endereço: %s\n" +
                                "Bairro: %s\n" +
                                "Cidade: %s\n" +
                                "Estado: %s\n" +
                                "Nº: %d\n" +
                                "Deseja finalizar o pedido?\n",
                        selectedRestaurant.getNome(),
                        productsSelected.stream().map(Product::getPreco).reduce(0.0f, (a, b) -> a + b),
                        selectedFormaPagamento.getNome(),
                        address.getPublicPlace(),
                        address.getNeighborhood(),
                        address.getCity(),
                        address.getState(),
                        address.getAddressNumber()
                );

                int completeOrderOption = JOptionPane.showConfirmDialog(
                        null,
                        completeOrderMessage,
                        "Deseja finalizar o pedido?",
                        JOptionPane.YES_NO_OPTION
                );

                if (completeOrderOption == 0) {
                    long addressId = addressRepository.create(address);
                    address.setId(addressId);

                    System.out.println("addressId: " + addressId);
                    StatusEntrega statusEntrega = new StatusEntrega(1, "produção");
                    float valorTotal = productsSelected.stream().map(Product::getPreco).reduce(0.0f, (a, b) -> a + b);
                    Order order = new Order(0, address, selectedFormaPagamento, statusEntrega, selectedRestaurant, valorTotal, LocalDate.now());

                    long orderId = orderRepository.create(order);

                    order.setId(orderId);

                    productCartRepository.createMany(order, productsSelected);

                    UpdateShippingStatusOrderRunnable updateShippingStatusOrderRunnable = new UpdateShippingStatusOrderRunnable(
                            order, orderRepository
                    );

                    Thread updateShippingStatusOrderThread = new Thread(updateShippingStatusOrderRunnable);
                    updateShippingStatusOrderThread.start();
                }
            } else if (menuOption.equals("2")) {

                ArrayList<Order> orders = orderRepository.listAllOrders();

                String orderMessage = "";

                for (int i = 0; i < orders.size(); i++) {
                    Order order = orders.get(i);
                    orderMessage += String.format("Restaurante: %s\nValor total: %.2f\n" +
                            "Método de pagamento: %s\nStatus de entrega: %s\n" +
                                    "----------------------------------\n",
                            order.getRestaurant().getNome(),
                            order.getValorTotal(),
                            order.getFormaPagamento().getNome(),
                            order.getStatusEntrega().getNome()
                    );
                }

                JOptionPane.showMessageDialog(null, orderMessage);
            } else {
                JOptionPane.showMessageDialog(null, "Sistema encerrado!");
                connection.close();
            }
        }
    }
}