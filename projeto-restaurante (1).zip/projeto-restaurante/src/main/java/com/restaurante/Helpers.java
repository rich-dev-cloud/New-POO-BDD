package com.restaurante;

public class Helpers {
    public static boolean isNumeric(String input) {
        if (input == null && input.isEmpty()) {
            return false;
        }

        try {
            Double.parseDouble(input);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
