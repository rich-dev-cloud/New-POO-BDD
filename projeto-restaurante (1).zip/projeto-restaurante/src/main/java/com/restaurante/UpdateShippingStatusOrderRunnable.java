package com.restaurante;

import com.restaurante.models.Order;
import com.restaurante.repository.OrderRepository;

import java.util.Random;

public class UpdateShippingStatusOrderRunnable implements Runnable {
    private Order order;
    private OrderRepository orderRepository;

    public UpdateShippingStatusOrderRunnable(Order order, OrderRepository orderRepository) {
        this.order = order;
        this.orderRepository = orderRepository;
    }

    @Override
    public void run() {
        try {
            int currentStatusEntrega = this.order.getStatusEntrega().getId();

            while (currentStatusEntrega != 3) {
                Random random = new Random();
                int min = 180000;
                int max = 360000;
                int timeInterval = min + random.nextInt(max - min + 1);

                System.out.printf("Intervalo: %d\n", timeInterval);
                Thread.sleep(timeInterval);

                currentStatusEntrega += 1;

                this.orderRepository.updatehippingStatusByOrderId(
                        this.order.getId(),
                        currentStatusEntrega
                );
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            Thread.currentThread().interrupt();
            System.out.println("Encerrando a thread");
        }
    }
}
