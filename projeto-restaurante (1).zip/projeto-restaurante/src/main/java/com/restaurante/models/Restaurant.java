package com.restaurante.models;

import java.util.ArrayList;

public class Restaurant {
    private int id;
    private String nome;
    private ArrayList<FormaPagamento> formaPagamentos;

    public Restaurant(int id, String nome, ArrayList<FormaPagamento> formaPagamentos) {
        this.id = id;
        this.nome = nome;
        this.formaPagamentos = formaPagamentos;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<FormaPagamento> getFormaPagamentos() {
        return this.formaPagamentos;
    }

    public void setFormaPagamentos(ArrayList<FormaPagamento> formaPagamentos) {
        this.formaPagamentos = formaPagamentos;
    }

    public void addFormaPagamento(FormaPagamento formaPagamento) {
        this.formaPagamentos.add(formaPagamento);
    }
}
