package com.restaurante.models;

public class ProductCart {
    private int id;
    private int produtoId;
    private int pedidoId;

    public ProductCart(int id, int produtoId, int pedidoId) {
        this.id = id;
        this.produtoId = produtoId;
        this.pedidoId = pedidoId;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int getProdutoId() {
        return this.produtoId;
    }

    private void setProdutoId(int produtoId) {
        this.produtoId = produtoId;
    }

    private int getPedidoId() {
        return this.pedidoId;
    }

    private void setPedidoId(int pedidoId) {
        this.pedidoId = pedidoId;
    }
}
