package com.restaurante.models;

public class Product {
    private int id;
    private String nome;
    private float preco;
    private int restauranteId;

    public Product(int id, String nome, float preco, int restauranteId) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.restauranteId = restauranteId;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPreco() {
        return this.preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public int getRestauranteId() {
        return this.restauranteId;
    }

    public void setRestauranteId(int restauranteId) {
        this.restauranteId = restauranteId;
    }
}
