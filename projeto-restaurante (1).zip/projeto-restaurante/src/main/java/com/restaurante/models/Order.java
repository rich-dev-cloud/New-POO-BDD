package com.restaurante.models;

import java.time.LocalDate;
import java.util.Date;

public class Order {
    private long id;
    private Address address;
    private FormaPagamento formaPagamento;
    private StatusEntrega statusEntrega;
    private Restaurant restaurant;
    private float valorTotal;
    private LocalDate date;

    public Order(
            long id,
            Address address,
            FormaPagamento formaPagamento,
            StatusEntrega statusEntrega,
            Restaurant restaurant,
            float valorTotal,
            LocalDate date
    ) {
        this.id = id;
        this.address = address;
        this.formaPagamento = formaPagamento;
        this.statusEntrega = statusEntrega;
        this.restaurant = restaurant;
        this.valorTotal = valorTotal;
        this.date = date;
    }

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Address getAddress() {
        return this.address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public FormaPagamento getFormaPagamento() {
        return this.formaPagamento;
    }

    public void setFormaPagamento(FormaPagamento formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public StatusEntrega getStatusEntrega() {
        return this.statusEntrega;
    }

    public void setStatusEntrega(StatusEntrega statusEntrega) {
        this.statusEntrega = statusEntrega;
    }

    public Restaurant getRestaurant() {
        return this.restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public float getValorTotal() {
        return this.valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public LocalDate getDate() {
        return this.date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
}
