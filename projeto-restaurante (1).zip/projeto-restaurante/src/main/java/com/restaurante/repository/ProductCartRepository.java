package com.restaurante.repository;

import com.restaurante.models.Order;
import com.restaurante.models.Product;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductCartRepository {
    private Connection connection = null;

    public ProductCartRepository(Connection connection) {
        this.connection = connection;
    }

    public void createMany(Order order, ArrayList<Product> produtos) {
        try {
            Statement statement = this.connection.createStatement();
            String sql = "";

            for (int i = 0; i < produtos.size(); i++) {
                sql += String.format(
                        "INSERT INTO produto_carrinho(produtoId, pedidoId) VALUES(%d, %d);",
                        produtos.get(i).getId(),
                        order.getId()
                );
            }

            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
