package com.restaurante.repository;

import com.restaurante.models.FormaPagamento;
import com.restaurante.models.Order;
import com.restaurante.models.Restaurant;
import com.restaurante.models.StatusEntrega;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Optional;

public class OrderRepository {
    private Connection connection;

    public OrderRepository(Connection connection) {
        this.connection = connection;
    }

    public long create(Order order) {
        try {
            Statement statement = this.connection.createStatement();
            String sql = String.format(
                    "INSERT INTO pedido(enderecoId, formaPagamentoId, statusEntregaId, valorTotal, restauranteId) VALUES(%d, %d, %d, %s, %d);",
                        order.getAddress().getId(),
                        order.getFormaPagamento().getId(),
                        order.getStatusEntrega().getId(),
                        String.valueOf(order.getValorTotal()),
                        order.getRestaurant().getId()
                    );

            int rowsAffected = statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
            long id = 0;

            if (rowsAffected > 0) {
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    id = generatedKeys.getLong(1);
                }
                generatedKeys.close();
            }

            statement.close();
            return id;
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public ArrayList<Order> listAllOrders() {
        ArrayList<Order> orders = new ArrayList<>();
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            statement = this.connection.createStatement();
            String sql = "SELECT p.*, r.nome as \"restauranteNome\", fp.nome as \"formaPagamentoNome\", se.nome as \"statusEntregaNome\"\n" +
                    "FROM pedido p\n" +
                    "LEFT JOIN restaurante r ON p.restauranteId = r.id\n" +
                    "LEFT JOIN forma_pagamento fp ON p.formaPagamentoId = fp.id\n" +
                    "LEFT JOIN status_entrega se ON p.statusEntregaId = se.id\n" +
                    "ORDER BY p.createdAt DESC\n" +
                    "LIMIT 5;";
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int restaurantId = resultSet.getInt("restauranteId");
                String restaurantNome = resultSet.getString("restauranteNome");
                int statusEntregaId = resultSet.getInt("statusEntregaId");
                String statusEntregaNome = resultSet.getString("statusEntregaNome");
                int formaPagamentoId = resultSet.getInt("formaPagamentoId");
                String formaPagamentoNome = resultSet.getString("formaPagamentoNome");
                float valorTotal = resultSet.getFloat("valorTotal");
                Date createdAt = resultSet.getDate("createdAt");
                LocalDate localDateCreatedAt = createdAt.toLocalDate();

                Restaurant restaurant = new Restaurant(restaurantId, restaurantNome, null);
                FormaPagamento formaPagamento = new FormaPagamento(formaPagamentoId, formaPagamentoNome);
                StatusEntrega statusEntrega = new StatusEntrega(statusEntregaId, statusEntregaNome);

                Order order = new Order(id, null, formaPagamento, statusEntrega, restaurant, valorTotal, localDateCreatedAt);
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
                if (resultSet != null) resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return orders;
    }

    public void updatehippingStatusByOrderId(long id, long statusEntregaId) {
        try {
            Statement statement = this.connection.createStatement();
            String sql = String.format(
                    "UPDATE pedido SET statusEntregaId = %d WHERE id = %d;",
                    statusEntregaId,
                    id
            );

            statement.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
