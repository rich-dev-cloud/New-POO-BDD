package com.restaurante.repository;

import com.restaurante.models.FormaPagamento;
import com.restaurante.models.Restaurant;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Optional;

public class RestaurantRepository {
    private Connection connection = null;

    public RestaurantRepository(Connection connection) {
        this.connection = connection;
    }

    public ArrayList<Restaurant> listAllRestaurants() {
        ArrayList<Restaurant> restaurants = new ArrayList<>();
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            statement = this.connection.createStatement();
            String sql = "SELECT r.*, fp.id AS formaPagamentoId, fp.nome as formaPagamentoNome\n" +
                    "FROM restaurante r\n" +
                    "LEFT JOIN restaurante_pagamento rp ON r.id = rp.restauranteId\n" +
                    "LEFT JOIN forma_pagamento fp ON rp.formaPagamentoId = fp.id;";
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nome = resultSet.getString("nome");
                int formaPagamentoId = resultSet.getInt("formaPagamentoId");
                String formaPagamentoNome = resultSet.getString("formaPagamentoNome");

                FormaPagamento formaPagamento = new FormaPagamento(formaPagamentoId, formaPagamentoNome);

                Optional<Restaurant> findRestaurant = restaurants.stream()
                        .filter(restaurant -> restaurant.getId() == id)
                        .findFirst();

                if (findRestaurant.isPresent()) {
                    findRestaurant.get().addFormaPagamento(formaPagamento);
                } else {
                    ArrayList<FormaPagamento> formaPagamentos = new ArrayList<>();
                    formaPagamentos.add(formaPagamento);
                    Restaurant restaurant = new Restaurant(id, nome, formaPagamentos);
                    restaurants.add(restaurant);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
                if (resultSet != null) resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return restaurants;
    }
}
