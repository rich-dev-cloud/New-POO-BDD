package com.restaurante.repository;

import com.restaurante.models.Address;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AddressRepository {
    private Connection connection = null;

    public AddressRepository(Connection connection) {
        this.connection = connection;
    }

    public long create(Address address) {
        try {
            Statement statement = this.connection.createStatement();
            String sql = String.format(
                    "INSERT INTO endereco(cep, estado, cidade, bairro, rua, numero) VALUES(\"%s\", \"%s\", \"%s\", \"%s\", \"%s\", %d);",
                    String.valueOf(address.getCep()),
                    address.getState(),
                    address.getCity(),
                    address.getNeighborhood(),
                    address.getPublicPlace(),
                    address.getAddressNumber()
            );

            int rowsAffected = statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
            long id = 0;

            if (rowsAffected > 0) {
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    id = generatedKeys.getLong(1);
                }
                generatedKeys.close();
            }

            statement.close();
            return id;
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
}

