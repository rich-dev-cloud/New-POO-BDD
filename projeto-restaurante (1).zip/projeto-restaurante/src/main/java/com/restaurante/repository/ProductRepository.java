package com.restaurante.repository;

import com.restaurante.models.Product;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProductRepository {
    private Connection connection = null;

    public ProductRepository(Connection connection) {
        this.connection = connection;
    }

    public ArrayList<Product> getOrdersByRestauranteId(int restaurantId) {
        ArrayList<Product> products = new ArrayList<Product>();
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            statement = this.connection.createStatement();
            String sql = String.format("SELECT * FROM produto WHERE restauranteId = %d", restaurantId);
            resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int produtoRestauranteId = resultSet.getInt("restauranteId");
                String nome = resultSet.getString("nome");
                float preco = resultSet.getFloat("preco");

                Product product = new Product(id, nome, preco, produtoRestauranteId);
                products.add(product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (statement != null) statement.close();
                if (resultSet != null) resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return products;
    }
}
