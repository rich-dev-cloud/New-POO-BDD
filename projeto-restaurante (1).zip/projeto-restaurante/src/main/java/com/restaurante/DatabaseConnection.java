package com.restaurante;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private Connection connection = null;
    private final String url = "jdbc:mysql://localhost:3308/restaurantedb?useSSL=false&allowPublicKeyRetrieval=true";
    private final String user = "root";
    private final String password = "root";

    public void connection() {
        try {
            this.connection = DriverManager.getConnection(this.url, this.user, this.password);
            System.out.println("Conexão bem sucedida!");
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco de dados!");
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return this.connection;
    }

    public void close() {
        try {
            this.connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
