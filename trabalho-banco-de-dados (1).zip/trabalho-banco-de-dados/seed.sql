USE restaurantedb;

-- inserção de categoria
INSERT INTO categoria(nome)
VALUES
	("Cozinha Brasileira Tradicional"),
    ("Cozinha Internacional"),
    ("Grelhados e Carnes"),
    ("Doces e Sobremesas");
-- fim da inserção de categoria

-- inserção de restaurante
INSERT INTO restaurante(nome, categoriaId)
VALUES
	("Sabores do Horizonte", 1),
    ("Cantinho da Serra", 1),
    ("Recanto do Sabor", 1),
    ("Estação Gourmnet", 2),
    ("Sabores da Vila", 1),
    ("Sabor Tropical", 3),
    ("Grelhados Gourmet", 3),
    ("Cantina Bella Itália", 2),
    ("Delícias do Sertão", 1),
    ("Doce Pecado", 4);
-- fim da inserção de restaurante
    
-- inserção de avaliacao
INSERT INTO avaliacao (restauranteId, descricao, nota) VALUES
(1, 'A comida estava deliciosa e o atendimento foi excelente! Voltarei mais vezes.', 5),
(2, 'Ambiente agradável, mas a comida demorou muito para chegar.', 3),
(3, 'Não recomendo. O prato veio frio e o garçom foi rude.', 1),
(4, 'Ótima experiência! Tudo perfeito, desde o sabor até a apresentação dos pratos.', 5),
(5, 'O preço é alto para o que oferecem. A comida é boa, mas nada excepcional.', 2),
(6, 'Lugar incrível, com pratos que superaram minhas expectativas.', 4),
(7, 'A sobremesa foi o destaque da noite. Recomendo o pudim de leite!', 5),
(8, 'Achei o ambiente barulhento e a carne passou do ponto.', 2),
(9, 'Excelente custo-benefício! Comida gostosa e preços justos.', 4),
(10, 'Infelizmente minha experiência não foi boa. O prato principal estava mal temperado.', 1);
-- fim da inserção de avaliacao
    
-- inserção produtos
INSERT INTO produto(restauranteId, nome, preco)
VALUES
	(1, "Risoto de Camarão", 68.90),
    (1, "Filé ao Molho Madeira", 55.50),
    (1, "Torta de Limão", 18.90),
    (2, "Feijoada Completa", 42),
    (2, "Costela no Bafo", 49.90),
    (2, "Pudim de Leite", 14.50),
    (3, "Pizza Portuguesa (Grande)", 48.90),
    (3, "Espaguete à Carbonara", 36),
    (3, "Brownie com Sorvete", 22),
    (4, "Hambúrguer Artesanal Clássico", 32.90),
    (4, "Batata Rústica com Ervas", 18),
    (4, "Milkshake de Nutella", 24.50),
    (5, "Moqueca de Peixe", 74),
    (5, "Caldinho de Feijão", 12),
    (5, "Mousse de Maracujá", 16),
    (6, "Moqueca de Camarão", 89.9),
    (6, "Filé de Tilápia Grelhado", 69.9),
    (6, "Salada Tropical com Frutas", 39.9),
    (7, "Picanha na Chapa", 94.9),
    (7, "Costela de Porco ao Barbecue", 84.9),
    (7, "Frango ao Molho Mostarda", 62.9),
    (8, "Lasanha Bolonhesa", 54.9),
    (8, "Fettuccine Alfredo", 49.9),
    (8, "Pizza Margherita (Grande)", 64.9),
    (9, "Baião de Dois com Carne de Sol", 59.9),
    (9, "Carneiro Assado na Brasa", 84.9),
    (9, "Galinhada Caipira", 54.9),
    (10, "Cheesecake de Frutas Vermelhas", 24.9),
    (10, "Brownie com Sorvete", 19.9),
    (10, "Pudim de Leite Condesado", 14.9);
-- fim da inserção de produtos
    
-- inserção forma pagamento
INSERT INTO forma_pagamento(nome)
VALUES
	("Cartão de Crédito"),
    ("Pix"),
    ("Em mãos");
-- fim da inserção forma pagamento
    
-- inserção restaurante pagamento
INSERT INTO restaurante_pagamento(restauranteId, formaPagamentoId)
VALUES
	(1, 1),
    (1, 2),
    (1, 3),
    (2, 1),
    (2, 2),
    (2, 3),
    (3, 1),
    (3, 2),
    (3, 3),
    (4, 1),
    (4, 2),
    (4, 3),
    (5, 3),
    (6, 1),
    (6, 2),
    (6, 3),
    (7, 1),
    (7, 2),
    (7, 3),
    (8, 1),
    (8, 2),
    (8, 3),
    (9, 1),
    (9, 2),
    (9, 3),
    (10, 1),
    (10, 2),
    (10, 3);
-- Fim da inserção restaurante pagamento

-- Inserção de status entrega
INSERT INTO status_entrega (nome)
VALUES
	("produção"),
    ("saiu para entrega"),
    ("entregue");
-- Fim da inserção de estatus entrega
    
-- inserção de acompanhamentos
INSERT INTO acompanhamento(nome, preco, produtoId)
VALUES
	("Chips de batata-doce crocante e molho de ervas", 8.9, 1),
    ("Purê de mandioquinha e legumes grelhados", 12.90, 2),
    ("Calda de frutas vermelhas", 5.9, 3),
    ("Couve refogada, farofa crocante, laranja fatiada e torresmo artesanal", 14.9, 4),
    ("Batatas rústicas com alecrim e molho barbecue caseiro", 16.9, 5),
    ("Calda extra de caramelo artesanal", 4.9, 6),
    ("Borda recheada de catupiry e molho de alho para mergulhar", 9.9, 7),
    ("Lascas de parmesão e fatia de pão italiano artesanal", 7.9, 8),
    ("Calda quente de chocolate e castanhas trituradas", 6.9, 9),
    ("Molho especial de maionese defumada e batatas fritas", 10.9, 10),
    ("Ketchup artesanal de tomate e pimenta", 4.9, 11),
    ("Chantilly, calda extra de Nutella e farofa doce crocante", 5.9, 12),
    ("Arroz branco, farofa de dendê e pirão cremoso", 15.9, 13),
    ("Torresmo crocante e cebolinha", 5.9, 14),
    ("Mousse de maracujá", 6.9, 15),
    ("Arroz com Coco e Castanhas", 12.9, 16),
    ("Purê de Banana-da-Terra", 9.9, 17),
    ("Molho de Iogurte com Hortelã", 6.9, 18),
    ("Farofa de Ovos e Bacon", 14.9, 19),
    ("Batatas Rústicas com Alecrim", 10.9, 20),
    ("Legumes Salteados", 8.9, 21),
    ("Pão de Alho com Queijo", 7.9, 22),
    ("Salada Caprese", 9.9, 23),
    ("Bordas Recheadas com Catupiry", 8.9, 24),
    ("Manteiga de Garrafa e Torresmo", 12.9, 25),
    ("Vinagrete e Farofa de Cuscuz", 14.9, 26),
    ("Quiabo Refogado", 8.9, 27),
    ("Calda de Framboesa", 5.9, 28),
    ("Farofa de Castanhas e Caramelo", 6.9, 29),
    ("Chantilly Artesanal", 4.9, 30);
-- Fim da inserção de acompanhamentos

-- inserção de endereços
INSERT INTO endereco(cep, estado, cidade, bairro, rua, numero)
VALUES
	("01010001", "São Paulo", "São Paulo", "Centro", "Rua da Liberade", 123),
    ("30110002", "Minas Gerais", "Belo Horizonte", "Lourdes", "Avenida Augusto de Lima", 456),
    ("40010003", "Bahia", "Salvador", "Comércio", "Rua Chile", 789),
    ("60010004", "Ceará", "Fortaleza", "Meireles", "Avenida Beira-Mar", 101),
    ("69010005", "Amazonas", "Manaus", "Centro", "Rua 10 de Julho", 202),
    ("80010006", "Paraná", "Curitiba", "Batel", "Alameda Dom Pedro II", 303),
    ("72010007", "Distrito Federal", "Brasília", "Asa Sul", "SQS 305 Bloco A", 405),
    ("88010008", "Santa Catarina", "Florianópolis", "Centro", "Rua Felipe Schmidt", 506),
    ("96010009", "Rio Grande do Sul", "Pelotas", "Areal", "Avenida Bento Gonçalves", 707),
    ("20010-010", "Rio de Janeiro", "Rio de Janeiro", "Lapa", "Avenida Mem de Sá", 808);
-- Fim da inserção de endereços    

-- Automação para gerar 10 pedidos aleatórios por mês
DELIMITER $$

CREATE PROCEDURE create_pedidos()
BEGIN 
	DECLARE mes INT DEFAULT 1;
    DECLARE contador INT;
    DECLARE limite_mes INT DEFAULT 12;
    DECLARE limite_contador INT DEFAULT 10;
    
    WHILE mes <= limite_mes DO
		SET contador = 1;
        
        WHILE contador <= limite_contador DO
			INSERT INTO pedido(enderecoId, formaPagamentoId, statusEntregaId, valorTotal, restauranteId, createdAt)
            SELECT 
				(SELECT id FROM endereco ORDER BY RAND() LIMIT 1) AS enderecoId,
				(SELECT id FROM forma_pagamento ORDER BY RAND() LIMIT 1) AS formaPagamentoId,
				(SELECT id FROM status_entrega ORDER BY RAND() LIMIT 1) AS statusEntregaId,
				0,
				(SELECT id FROM restaurante ORDER BY RAND() LIMIT 1) AS restauranteId,
                DATE_ADD(
					CONCAT('2024-', LPAD(mes, 2, '0'), '-01'),
					INTERVAL FLOOR(RAND() * DAY(LAST_DAY(CONCAT('2024-', LPAD(mes, 2, '0'), '-01')))) DAY
				) AS createdAt;
			SET contador = contador + 1;
		END WHILE;
		
        SET mes = mes + 1;
	END WHILE;
END$$

DELIMITER ;

CALL create_pedidos();
-- Fim da automação para gerar 10 pedidos aleatórios por mês

-- Automação para gerar os itens de cada pedido
DELIMITER $$

CREATE PROCEDURE create_itens()
BEGIN
    DECLARE v_pedidoId INT;
    DECLARE v_restauranteId INT;
    DECLARE contador INT;
    DECLARE valorTotal FLOAT DEFAULT 0;
    DECLARE produtoId INT;
    DECLARE limite_contador INT;
    
    DECLARE done INT DEFAULT 0;
    
    DECLARE cur CURSOR FOR
        SELECT id, restauranteId FROM pedido;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    OPEN cur;
    
    leitura_loop: LOOP
        FETCH cur INTO v_pedidoId, v_restauranteId;
        IF done THEN
            LEAVE leitura_loop;
        END IF;
        
        SET contador = 1;
        SET limite_contador = FLOOR(RAND() * 3 + 1);
        
        SET valorTotal = 0;

        WHILE contador <= limite_contador DO
            SET produtoId = (SELECT id FROM produto WHERE restauranteId = v_restauranteId 
                ORDER BY RAND() LIMIT 1);
            
            SET valorTotal = valorTotal + (SELECT preco FROM produto WHERE id = produtoId);
            
            INSERT INTO produto_carrinho(pedidoId, produtoId) VALUES (v_pedidoId, produtoId);
            
            SET contador = contador + 1;
        END WHILE;
        
        UPDATE pedido
            SET valorTotal = valorTotal
        WHERE id = v_pedidoId;
    END LOOP;
    
    CLOSE cur;
END$$

DELIMITER ;

CALL create_itens();
-- Fim da automação de criação de produtos


