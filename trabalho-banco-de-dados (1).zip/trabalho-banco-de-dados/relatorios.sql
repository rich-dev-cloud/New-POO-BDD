USE restaurantedb;

-- Produto que mais vendeu
SELECT pd.nome, pd.preco, COUNT(pd.id) AS "frequencia" FROM pedido p
	INNER JOIN produto_carrinho pc ON pc.pedidoId = p.id
    INNER JOIN produto pd ON pd.id = pc.produtoId
WHERE p.restauranteId = 1
GROUP BY pd.id
ORDER BY frequencia DESC
LIMIT 1;
-- fim produto que mais vendeu

-- Produto que menos vendeu
SELECT pd.nome, pd.preco, COUNT(pd.id) AS "frequencia" FROM pedido p
	INNER JOIN produto_carrinho pc ON pc.pedidoId = p.id
    INNER JOIN produto pd ON pd.id = pc.produtoId
WHERE p.restauranteId = 1
GROUP BY pd.id
ORDER BY frequencia ASC
LIMIT 1;
-- fim produto que menos vendeu

-- Mês com mais vendas
SELECT 
	DATE_FORMAT(createdAt, '%Y-%m') AS mes_ano,
	COUNT(*) AS quantidade
FROM pedido
GROUP BY mes_ano
ORDER BY quantidade DESC
LIMIT 1;
-- Fim do mês com mais vendas

-- Forma de pagamento mais usado
SELECT fp.nome, COUNT(fp.id) AS "frequencia" FROM pedido p
INNER JOIN restaurante_pagamento rp ON p.formaPagamentoId = rp.id
INNER JOIN forma_pagamento fp ON rp.formaPagamentoId = fp.id
WHERE p.restauranteId = 1
GROUP BY fp.id
ORDER BY frequencia DESC
LIMIT 1;
-- Fim forma de pagamento mais usado

-- Endereço que mais teve entrega
SELECT e.*, COUNT(e.id) AS "frequencia" FROM pedido p
INNER JOIN endereco e ON p.enderecoId = e.id
WHERE p.restauranteId = 1
GROUP BY e.id
ORDER BY frequencia DESC
LIMIT 1;
-- Fim endereço que mais teve entrega

-- Pedido com mais itens
SELECT 
    pc.pedidoId, 
    COUNT(pc.pedidoId) AS frequencia
FROM pedido p
INNER JOIN produto_carrinho pc ON pc.pedidoId = p.id
WHERE p.restauranteId = 1
GROUP BY pc.pedidoId
ORDER BY frequencia DESC
LIMIT 1;
-- Fim pedido com mais itens

-- Venda do mês atual por pagamento
SELECT SUM(p.valorTotal) AS "receita", fp.nome AS "método de pagamento" FROM pedido p
INNER JOIN restaurante_pagamento rp ON p.formaPagamentoId = rp.id
INNER JOIN forma_pagamento fp ON rp.formaPagamentoId = fp.id
WHERE p.restauranteId = 2 AND DATE_FORMAT(createdAt, '%Y-%m') = DATE_FORMAT(CURRENT_TIMESTAMP, '%Y-%m')
GROUP BY fp.id
ORDER BY receita DESC;
-- Fim venda por mês atual por pagamento

-- Venda do mês anterior por pagamento
SELECT SUM(p.valorTotal) AS "receita", fp.nome AS "método de pagamento" FROM pedido p
INNER JOIN restaurante_pagamento rp ON p.formaPagamentoId = rp.id
INNER JOIN forma_pagamento fp ON rp.formaPagamentoId = fp.id
WHERE p.restauranteId = 3
	AND DATE_FORMAT(createdAt, '%Y-%m') = DATE_FORMAT(DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 1 MONTH), '%Y-%m')
GROUP BY fp.id
ORDER BY receita DESC;
-- Fim venda por mês anterior por pagamento
